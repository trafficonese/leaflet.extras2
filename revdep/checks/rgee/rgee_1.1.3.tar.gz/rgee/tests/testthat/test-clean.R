context("rgee: ee_clean_credentials test")
skip_if_no_pypkg()
# -------------------------------------------------------------------------
#test_that("ee_clean_credentials", {
  #result_True <- ee_clean_credentials('test')
  #expect_true(result_True)
#})

# test_that("ee_clean_credentials not-defined", {
#   result_True <- ee_clean_pyenv()
#   expect_true(result_True)
# })
