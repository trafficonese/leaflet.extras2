context("rgee: ee_install test")
skip_if_no_pypkg()
# -------------------------------------------------------------------------

### Instalation module
# test_that("ee_install_create_pyenv ",{
#   result <- ee_install_create_pyenv('earthengine_test')
#   expect_type(result,"character")
# })
#
# test_that("ee_install_discover_pyenvs",{
#   python_envs <- ee_install_discover_pyenvs()
#   expect_equal(class(python_envs), 'character')
# })
#
# test_that("ee_install_set_pyenv",{
#   python_envs <- ee_install_discover_pyenvs()
#   fmsg <- ee_install_set_pyenv(py_path = python_envs[3])
#   expect_true(fmsg)
# })
